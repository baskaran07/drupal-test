/**
 * @file
 * Contains js for the accordion example.
 */

(function ($) {

  'use strict';

  $(function () {
    $('#accordion').accordion();
  });
})(jQuery);
