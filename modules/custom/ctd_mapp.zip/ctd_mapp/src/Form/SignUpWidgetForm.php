<?php

namespace Drupal\ctd_mapp\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\ctd_mapp\EmsApi;
use Drupal\ctd_mapp\Subscriber\Subscriber;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Mapp newsletter signup form with configurable fields.
 */
class SignUpWidgetForm extends FormBase {

  /** @var string */
  protected $uniqueId;

  /** @var ImmutableConfig */
  protected $config;

  /**
   * Contains options for which Mapp subscriber fields to show in the form.
   *
   * Set any key to a truthy value to enable a field.
   * Allowed array keys:
   * 'first_name'
   * 'last_name'
   * 'birth_date'
   * 'address'
   * 'city'
   * 'state'
   * 'postal_code'
   * 'country'
   *
   * @var array
   */
  protected $enabledFields;

  /** @var  EmsApi */
  protected $emsApi;


  /**
   * @param EmsApi      $emsApi
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   * @param string|null $uniqueId
   */
  public function __construct(EmsApi $emsApi, ConfigFactoryInterface $configFactory, $uniqueId = NULL) {
    $this->emsApi   = $emsApi;
    $this->config   = $configFactory->get('ctd_mapp.config');
    $this->uniqueId = $uniqueId;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('ctd_mapp.ems_api'),
      $container->get('config.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ctd_mapp_signup_' . ($this->uniqueId ?: 'form');
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, array $enabledFields = [], $uniqueId = NULL) {
    $this->uniqueId      = $uniqueId ?: $this->uniqueId;
    $this->enabledFields = $enabledFields;

    // Multiple signup forms can exist on the same page. Create a unique
    // wrapper based on the form ID.
    $wrapperId = $this->uniqueId . '-ajax-wrapper';

    $form['#prefix'] = '<div id="' . $wrapperId . '">';
    $form['#suffix'] = '</div>';
    $form['email']   = [
      '#type'       => 'email',
      '#title'      => $this->t('Email'),
      '#required'   => TRUE,
      '#maxlength'  => 132,
      '#attributes' => [
        'placeholder' => 'E-Mail Address',
      ],
    ];

    // Create form fields.
    foreach ($enabledFields as $fieldName => $isEnabled) {
      if (empty($isEnabled)) {
        continue;
      }
      $formattedFieldName = ucwords(str_replace('_', ' ', $fieldName));

      // For birth date, we want '#type' = 'date' and '#required' = FALSE, everything else is 'textfield' and TRUE.
      // We also check if 'birth_date_field' still has a value since the widget was created.
      if ($fieldName === 'birth_date') {
        if ($this->config->get('birth_date_field')) {
          $form[$fieldName] = [
            '#type'      => 'date',
            '#title'     => $formattedFieldName,
            '#required'  => FALSE,
            '#maxlength' => 64,
          ];
        }
      }
      else {
        $form[$fieldName] = [
          '#type' => 'textfield',
          '#title' => $formattedFieldName,
          '#required' => TRUE,
          '#maxlength' => 64,
        ];
      }
    }

    // Used as placeholder for ajax messages.
    $form['message'] = [];

    // The form submit button needs a unique ID so that other sign up widget
    // on the page are not processed. This also prevents the page from jumping
    // to the first form on the page.
    // See https://www.drupal.org/project/drupal/issues/1342066#comment-12433457.
    $form['submit-' . $this->getFormId()] = [
      '#type' => 'submit',
      '#name' => 'submit-' . $this->getFormId(),
      '#ajax' => [
        'wrapper' => $wrapperId,
        'callback' => '::ajaxSignUpCallback',
      ],
      '#value' => $this->t('Sign Up'),
    ];

    honeypot_add_form_protection($form, $form_state, ['honeypot', 'time_restriction']);

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // AJAX is forced so that errors are not accidentally cached.
  }

  /**
   * Implements callback for Ajax event on form submit.
   *
   * @param array $form
   *   From render array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   Current state of form.
   *
   * @return array
   *   The form.
   */
  public function ajaxSignUpCallback(array $form, FormStateInterface $form_state) {
    $errors = $form_state->getErrors();

    if (!empty($errors)) {
      // We do not want error messages to display in the status block since we
      // create our own styled messages below.
      unset($_SESSION['messages']['error']);

      // If errors exist, return the errors before any API calls.
      return $form;
    }

    $subscriber = new Subscriber($form_state->getValue('email'));
    $subscriber->setFirstName($form_state->getValue('first_name'))
      ->setLastName($form_state->getValue('last_name'))
      ->setAddress($form_state->getValue('address'))
      ->setBirthDate($form_state->getValue('birth_date'))
      ->setCity($form_state->getValue('city'))
      ->setState($form_state->getValue('state'))
      ->setCountry($form_state->getValue('country'))
      ->setPostalCode($form_state->getValue('postal_code'));

    $response = $this->emsApi->addSubscriber($subscriber);

    if ($response) {
      $form['message'] = [
        '#prefix' => '<div class="alert alert-success alert-dismissible" role="alert"><a role="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></a><h4 class="sr-only">Success message</h4>',
        '#markup' => '<span class="glyphicon glyphicon-ok" aria-hidden="true"></span> <strong>Thank you. Your information has been submitted.</strong>',
        '#suffix' => '</div>',
      ];
    }
    else {
      $form['message'] = [
        '#prefix' => '<div class="alert alert-danger alert-dismissible" role="alert"><a role="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></a><h4 class="sr-only">Error message</h4>',
        '#markup' => '<span class="glyphicon glyphicon-ban-circle" aria-hidden="true"></span> <strong>Error occurred when subscribing to newsletter. Please try again.</strong>',
        '#suffix' => '</div>',
      ];
    }

    return $form;
  }
}
