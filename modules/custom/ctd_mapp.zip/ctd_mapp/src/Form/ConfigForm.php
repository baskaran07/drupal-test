<?php

namespace Drupal\ctd_mapp\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Mapp configuration.
 */
class ConfigForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'ctd_mapp.config',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ctd_mapp_config_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('ctd_mapp.config');

    $form['api_key'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('eMS API Key'),
      '#default_value' => $config->get('api_key'),
    ];

    $form['shared_secret'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('eMS Shared Secret'),
      '#default_value' => $config->get('shared_secret'),
    ];

    $form['birth_date_field'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Custom Birth Date Field ID'),
      '#suffix'         => 'ID of the site\'s custom birth date field. Ex: 332221',
      '#default_value' => $config->get('birth_date_field'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);

    $this->config('ctd_mapp.config')
      ->set('api_key', $form_state->getValue('api_key'))
      ->set('shared_secret', $form_state->getValue('shared_secret'))
      ->set('birth_date_field', $form_state->getValue('birth_date_field'))
      ->save();
  }

}
