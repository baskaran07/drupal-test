<?php

namespace Drupal\ctd_mapp\Subscriber;

/**
 * Data object representing a newsletter subscriber.
 */
class Subscriber {

  /** @var string */
  protected $email;

  /** @var string */
  protected $firstName;

  /** @var string */
  protected $lastName;

  /** @var string */
  protected $birthDate;

  /** @var string */
  protected $address;

  /** @var string */
  protected $city;

  /** @var string */
  protected $state;

  /** @var string */
  protected $country;

  /** @var string */
  protected $postalCode;

  /**
   * @param string $email
   */
  public function __construct($email) {
    $this->email = $email;
  }

  /**
   * @return string
   */
  public function getEmail() {
    return $this->email;
  }

  /**
   * @param string $email
   *
   * @return $this
   */
  public function setEmail($email) {
    $this->email = $email;
    return $this;
  }

  /**
   * @return string|null
   */
  public function getFirstName() {
    return $this->firstName;
  }

  /**
   * Sets the firstName parameter.
   *
   * @param string $firstName
   *
   * @return $this
   */
  public function setFirstName($firstName) {
    $this->firstName = $firstName;
    return $this;
  }

  /**
   * @return string|null
   */
  public function getLastName() {
    return $this->lastName;
  }

  /**
   * @param string $lastName
   *
   * @return $this
   */
  public function setLastName($lastName) {
    $this->lastName = $lastName;
    return $this;
  }

  /**
   * @return string|null
   */
  public function getBirthDate() {
    return $this->birthDate;
  }

  /**
   * @param string $birthDate
   *
   * @return $this
   */
  public function setBirthDate($birthDate) {
    if (empty($birthDate)) {
      $this->birthDate = NULL;
      return $this;
    }
    try {
      $birthDate = new \DateTime($birthDate);
      $this->birthDate = $birthDate->format('Y-m-d');
      return $this;
    }
    catch (\Exception $e) {
      $this->birthDate = NULL;
      return $this;
    }
  }

  /**
   * @return string|null
   */
  public function getAddress() {
    return $this->address;
  }

  /**
   * @param string $address
   *
   * @return $this
   */
  public function setAddress($address) {
    $this->address = $address;
    return $this;
  }

  /**
   * @return string|null
   */
  public function getCity() {
    return $this->city;
  }

  /**
   * @param string $city
   *
   * @return $this
   */
  public function setCity($city) {
    $this->city = $city;
    return $this;
  }

  /**
   * @return string|null
   */
  public function getState() {
    return $this->state;
  }

  /**
   * @param string $state
   *
   * @return $this
   */
  public function setState($state) {
    $this->state = $state;
    return $this;
  }

  /**
   * @return string|null
   */
  public function getCountry() {
    return $this->country;
  }

  /**
   * @param string $country
   *
   * @return $this
   */
  public function setCountry($country) {
    $this->country = $country;
    return $this;
  }

  /**
   * @return string|null
   */
  public function getPostalCode() {
    return $this->postalCode;
  }

  /**
   * @param string $postalCode
   *
   * @return $this
   */
  public function setPostalCode($postalCode) {
    $this->postalCode = $postalCode;
    return $this;
  }

}
