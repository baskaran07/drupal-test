<?php

namespace Drupal\ctd_mapp;

use Drupal\ctd_mapp\Subscriber\Subscriber;
use SimpleXMLElement;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;


/**
 * Mapp eMS API SDK.
 */
class EmsApi {

  /** @var  ImmutableConfig */
  private $config;

  /**
   * EmsApi constructor.
   *
   * @param ConfigFactoryInterface $configFactory
   */
  public function __construct(ConfigFactoryInterface $configFactory) {
    $this->config = $configFactory->get('ctd_mapp.config');
  }

  /**
   * Adds a subscriber to the Mapp eMS.
   *
   * @param Subscriber $subscriber
   *   The information of the new subscriber.
   *
   * @return bool
   *   Returns TRUE if the subscriber was added successfully.
   */
  public function addSubscriber(Subscriber $subscriber) {
    $subscriberInfo = [
      'email' => $subscriber->getEmail(),
      'firstname' => $subscriber->getFirstName(),
      'lastname' => $subscriber->getLastName(),
      'address' => $subscriber->getAddress(),
      'city' => $subscriber->getCity(),
      'state' => $subscriber->getState(),
      'postal_code' => $subscriber->getPostalCode(),
      'country' => $subscriber->getCountry(),
    ];
    if ($birthDateField = $this->config->get('birth_date_field')) {
      $subscriberInfo['custval' . $birthDateField] = $subscriber->getBirthDate();
    }
    return $this->request('legacy.manage_subscriber', $subscriberInfo);
  }

  /**
   * Performs a request to the Mapp eMS.
   *
   * @param string $method
   *   The API method.
   * @param array $data
   *   The values for the API call.
   *
   * @return bool
   *   Returns TRUE if successful.
   */
  public function request($method, array $data) {
    try {
      $xml = $this->getRequestXml($method, $data);

      $client = \Drupal::httpClient();
      $response = $client->post('https://echo.bluehornet.com/api/xmlrpc/index.php', [
        'headers' => [
          'Accept' => 'application/x-www-form-urlencoded',
        ],
        'body' => $xml,
      ]);

      $response = (string) $response->getBody();
      $response = unserialize($response);

      // The response does not always contain the response code in the same
      // place.Perform an additional check to make sure it is set.
      // This is where it is set when successful.
      $responseCode = isset($response[0]['responseCode']) ? $response[0]['responseCode'] : NULL;

      if (isset($responseCode) && $responseCode >= 200 && $responseCode < 300) {
        return TRUE;
      }
      else {
        return FALSE;
      }
    }
    catch (\Exception $e) {
      \Drupal::logger('ctd_mapp')->error($e->getMessage());

      return FALSE;
    }
  }

  /**
   * Gets the XML needed for an API call to the Mapp eMS.
   *
   * @param string $method
   *   The API method.
   * @param array $values
   *   The values for the API call.
   *
   * @return string
   */
  protected function getRequestXml($method, array $values) {
    $data = [
      'authentication' => [
        'api_key' => $this->config->get('api_key'),
        'shared_secret' => $this->config->get('shared_secret'),
        'response_type' => 'php',
      ],
      'data' => [
        'methodCall' => [
          'methodName' => $method,
        ],
      ],
    ];

    foreach ($values as $key => $value) {
      $data['data']['methodCall'][$key] = $value;
    }

    $xml = new \SimpleXMLElement('<api/>');
    $xml = $this->arrayToXml($data, $xml);

    return $xml->asXML();
  }

  /**
   * Generates XML from an array.
   *
   * @param array $data
   *   The data.
   * @param \SimpleXMLElement $xml
   *   SimpleXMLElement to add the xml to.
   *
   * @return \SimpleXMLElement
   */
  protected function arrayToXml(array $data, SimpleXMLElement $xml) {
    foreach ($data as $key => $value) {
      if (is_array($value)) {
        $subnode = $xml->addChild($key);
        $this->arrayToXml($value, $subnode);
      }
      else {
        $xml->addChild("$key", htmlspecialchars("$value"));
      }
    }

    return $xml;
  }

}

