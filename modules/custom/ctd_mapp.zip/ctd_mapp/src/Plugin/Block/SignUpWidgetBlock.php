<?php

namespace Drupal\ctd_mapp\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\ctd_mapp\EmsApi;
use Drupal\ctd_mapp\Form\SignUpWidgetForm;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a Mapp newsletter signup block with configurable fields.
 *
 * @Block(
 *  id = "ctd_mapp_sign_up_widget_block",
 *  admin_label = @Translation("Mapp Sign Up Widget"),
 * )
 */
class SignUpWidgetBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /** @var  FormBuilderInterface */
  protected $formBuilder;

  /** @var  EmsApi */
  protected $emsApi;

  /** @var ImmutableConfig */
  protected $configFactory;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    FormBuilderInterface $formBuilder,
    EmsApi $emsApi,
    ConfigFactoryInterface $configFactory
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->formBuilder   = $formBuilder;
    $this->emsApi        = $emsApi;
    $this->configFactory = $configFactory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('form_builder'),
      $container->get('ctd_mapp.ems_api'),
      $container->get('config.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'enabled_fields' => [
        'first_name'  => FALSE,
        'last_name'   => FALSE,
        'birth_date'  => FALSE,
        'address'     => FALSE,
        'city'        => FALSE,
        'state'       => FALSE,
        'postal_code' => FALSE,
        'country'     => FALSE,
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $form = parent::blockForm($form, $form_state);

    $form['enabled_fields'] = [
      '#type' => 'checkboxes',
      '#options' => [
        'first_name'  => $this->t('First Name'),
        'last_name'   => $this->t('Last Name'),
        'address'     => $this->t('Street Address'),
        'city'        => $this->t('City'),
        'state'       => $this->t('State'),
        'postal_code' => $this->t('Postal Code'),
        'country'     => $this->t('Country'),
      ],
      '#title' => 'Which elements do you want included in the form? (Email is included by default)',
      '#default_value' => $this->getEnabledFields(),
    ];
    if ($this->configFactory->get('ctd_mapp.config')->get('birth_date_field')) {
      $form['enabled_fields']['#options']['birth_date'] = $this->t('Date of Birth');
    }
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    parent::blockSubmit($form, $form_state);
    $values = $form_state->getValues();
    $this->setFormId($form['id']['#default_value']);
    $this->setEnabledFields($values['enabled_fields']);
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    // Pass the block's form ID to sign up form to differentiate multiple
    // sign up forms on the same page.
    $form = new SignUpWidgetForm($this->emsApi, $this->configFactory, $this->getFormId());

    $build = [
      '#theme' => 'ctd_mapp_sign_up_widget',
      '#form'  => $this->formBuilder->getForm($form, $this->getEnabledFields()),
    ];

    return $build;
  }

  /**
   * @return array
   */
  protected function getEnabledFields() {
    return $this->configuration['enabled_fields'];
  }

  /**
   * @param array $enabledFields
   */
  protected function setEnabledFields(array $enabledFields) {
    $this->configuration['enabled_fields'] = $enabledFields;
  }

  /**
   * @return string
   */
  protected function getFormId() {
    return $this->configuration['form_id'];
  }

  /**
   * @param string $formId
   */
  protected function setFormId($formId) {
    $this->configuration['form_id'] = $formId;
  }

}