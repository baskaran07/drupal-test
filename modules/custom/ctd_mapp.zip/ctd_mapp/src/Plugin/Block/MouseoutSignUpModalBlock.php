<?php

namespace Drupal\ctd_mapp\Plugin\Block;

/**
 * Provides a 'SignUpModalBlock' block.
 *
 * @Block(
 *  id = "ctd_mapp_mouseout_sign_up_modal_block",
 *  admin_label = @Translation("Mapp Mouse Leaving Site Sign Up Modal"),
 * )
 */
class MouseoutSignUpModalBlock extends SignUpWidgetBlock {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = parent::build();

    $build['#theme'] = 'ctd_mapp_sign_up_mouseout_modal';

    return $build;
  }

}
