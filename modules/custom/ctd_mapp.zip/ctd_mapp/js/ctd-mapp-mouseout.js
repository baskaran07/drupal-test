(function ($, window) {
  'use strict';

  function initMouseoutModal() {
    // Create a mouseout event to show modal.
    $(window).on('mouseout.ctdMappModal', function (e) {
      // Only show the modal if the user mouses out of the top of the window.
      if (e.clientY <= 0) {
        // Show the modal.
        $('#newsletter-signup-modal').modal();
        // Ensure we don't show it on future site views.
        window.localStorage.setItem('hasBeenHere', 'true');
        // Destroy the mouseout event so it does not fire again after the first
        // time in the first session.
        $(window).off('mouseout.ctdMappModal');
      }
    });
  }

  $(document).ready(function () {
    // If a variable is not yet set localStorage will return null.
    // If not first visit skip creating mouseout event.
    if (!window.localStorage.getItem('hasBeenHere')) {
      initMouseoutModal();
    }
  });
})(jQuery, window);
