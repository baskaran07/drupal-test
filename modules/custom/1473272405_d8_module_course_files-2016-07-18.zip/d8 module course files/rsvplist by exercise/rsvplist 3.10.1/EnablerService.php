<?php
/**
 * @file
 * Contains \Drupal\rsvplist\EnablerService.
 */

namespace Drupal\rsvplist;

use Drupal\Core\Database\Database;
use Drupal\node\Entity\Node;

/**
 * Defines a service for managing RSVP list enabled for nodes.
 */
class EnablerService {
  /**
   * Constructor.
   */
  public function __construct() {

  }

}
