<?php

namespace Drupal\mymodule;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;

class MessageTypeListBuilder extends ConfigEntityListBuilder {

}
