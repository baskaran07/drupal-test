<?php
/**
 * Created by PhpStorm.
 * User: mglaman
 * Date: 12/24/15
 * Time: 12:43 AM
 */

namespace Drupal\mymodule;


use Drupal\Core\Config\Entity\ConfigEntityListBuilder;

class MessageTypeListBuilder extends ConfigEntityListBuilder {

}
