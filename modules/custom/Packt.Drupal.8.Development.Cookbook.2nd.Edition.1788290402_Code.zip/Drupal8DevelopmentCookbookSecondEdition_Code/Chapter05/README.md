Chapter 5: Frontend for the Win
===============================

This contains the theme built throughout each recipe in the chapter, in the `mytheme` directory.