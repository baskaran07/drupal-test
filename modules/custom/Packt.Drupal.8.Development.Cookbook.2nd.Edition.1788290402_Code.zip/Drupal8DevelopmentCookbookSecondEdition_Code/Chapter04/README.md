Chapter 4: Extending Drupal
===========================

The `mymodule` directory contains the module from the following recipes:

* Creating a module
* Defining a custom page
* Defining permissions
* Providing the configuration on installation or update

The **Creating an event subscriber** recipe can be found in `event_subscriber`. The `event_subscriber_di` directory contains the Dependency Injection example from the **There's more** section.