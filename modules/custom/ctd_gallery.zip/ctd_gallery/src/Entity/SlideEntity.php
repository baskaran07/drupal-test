<?php

namespace Drupal\ctd_gallery\Entity;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\RevisionableContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\media_entity\Entity\Media;
use Drupal\user\UserInterface;

/**
 * Defines the Slide entity.
 *
 * @ingroup ctd_gallery
 *
 * @ContentEntityType(
 *   id = "slide",
 *   label = @Translation("Slide"),
 *   handlers = {
 *     "storage" = "Drupal\ctd_gallery\SlideEntityStorage",
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\ctd_gallery\SlideEntityListBuilder",
 *     "views_data" = "Drupal\ctd_gallery\Entity\SlideEntityViewsData",
 *
 *     "form" = {
 *       "default" = "Drupal\ctd_gallery\Form\SlideEntityForm",
 *       "add" = "Drupal\ctd_gallery\Form\SlideEntityForm",
 *       "edit" = "Drupal\ctd_gallery\Form\SlideEntityForm",
 *       "delete" = "Drupal\ctd_gallery\Form\SlideEntityDeleteForm",
 *     },
 *     "access" = "Drupal\ctd_gallery\SlideEntityAccessControlHandler",
 *     "route_provider" = {
 *       "html" = "Drupal\ctd_gallery\SlideEntityHtmlRouteProvider",
 *     },
 *   },
 *   base_table = "slide",
 *   revision_table = "slide_revision",
 *   revision_data_table = "slide_field_revision",
 *   admin_permission = "administer slide entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "revision" = "vid",
 *     "label" = "title",
 *     "uuid" = "uuid",
 *     "uid" = "user_id",
 *     "langcode" = "langcode",
 *     "status" = "status",
 *   },
 *   links = {
 *     "canonical" = "/ctd_gallery/{gallery}/{slide}",
 *     "add-form" = "/admin/structure/slide/add",
 *     "edit-form" = "/admin/structure/slide/{slide}/edit",
 *     "delete-form" = "/admin/structure/slide/{slide}/delete",
 *     "version-history" = "/admin/structure/slide/{slide}/revisions",
 *     "revision" = "/ctd_gallery/{gallery}/{slide}/revisions/{slide_revision}/view",
 *     "revision_revert" = "/admin/structure/slide/{slide}/revisions/{slide_revision}/revert",
 *     "revision_delete" = "/admin/structure/slide/{slide}/revisions/{slide_revision}/delete",
 *     "collection" = "/admin/structure/slide",
 *   },
 *   field_ui_base_route = "slide.settings"
 * )
 */
class SlideEntity extends RevisionableContentEntityBase implements SlideEntityInterface {

  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public static function preCreate(EntityStorageInterface $storage_controller, array &$values) {
    parent::preCreate($storage_controller, $values);
    $values += [
      'user_id' => \Drupal::currentUser()->id(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function preSave(EntityStorageInterface $storage) {
    parent::preSave($storage);

    foreach (array_keys($this->getTranslationLanguages()) as $langcode) {
      $translation = $this->getTranslation($langcode);

      // If no owner has been set explicitly, make the anonymous user the owner.
      if (!$translation->getOwner()) {
        $translation->setOwnerId(0);
      }
    }

    // If no revision author has been set explicitly, make the slide owner the
    // revision author.
    if (!$this->getRevisionUser()) {
      $this->setRevisionUserId($this->getOwnerId());
    }
  }

  /**
   * {@inheritdoc}
   */
  public function gettitle() {
    return $this->get('title')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function settitle($title) {
    $this->set('title', $title);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getCreatedTime() {
    return $this->get('created')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setCreatedTime($timestamp) {
    $this->set('created', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getOwner() {
    return $this->get('user_id')->entity;
  }

  /**
   * {@inheritdoc}
   */
  public function getOwnerId() {
    return $this->get('user_id')->target_id;
  }

  /**
   * {@inheritdoc}
   */
  public function setOwnerId($uid) {
    $this->set('user_id', $uid);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function setOwner(UserInterface $account) {
    $this->set('user_id', $account->id());
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function isPublished() {
    return (bool) $this->getEntityKey('status');
  }

  /**
   * {@inheritdoc}
   */
  public function setPublished($published) {
    $this->set('status', $published ? TRUE : FALSE);
    return $this;
  }

  /**
   * Retrieves the media bundle id of the entity (ie image, instagram, etc)
   *
   * @return Drupal\media_entity\Entity\Media|null
   */
  public function getMediaBundle() {
    $referencedEntities = $this->referencedEntities();
    if ($referencedEntities) {
      foreach($referencedEntities as $reference) {
        if ($reference instanceof Media) {
          return $reference->bundle();
        }
      }
    }
    return NULL;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['user_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Authored by'))
      ->setDescription(t('The user ID of author of the Slide entity.'))
      ->setRevisionable(TRUE)
      ->setSetting('target_type', 'user')
      ->setSetting('handler', 'default')
      ->setTranslatable(TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'author',
        'weight' => 0,
      ])
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'weight' => 5,
        'settings' => [
          'match_operator' => 'CONTAINS',
          'size' => '60',
          'autocomplete_type' => 'tags',
          'placeholder' => '',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Slide Title'))
      ->setDescription(t('The title of the Slide entity.'))
      ->setRevisionable(TRUE)
      ->setSettings([
        'max_length' => 255,
        'text_processing' => 0,
      ])
      ->setRequired(TRUE)
      ->setDefaultValue('')
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -4,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Publishing status'))
      ->setDescription(t('A boolean indicating whether the Slide is published.'))
      ->setRevisionable(TRUE)
      ->setDefaultValue(TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'))
      ->setDescription(t('The time that the entity was created.'));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the entity was last edited.'));

    $fields['revision_log_message']->setDisplayConfigurable('form', TRUE);

    return $fields;
  }

}
