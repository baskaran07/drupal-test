<?php

namespace Drupal\ctd_gallery\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 *  Gallery SettingsForm
 *
 * @package Drupal\ctd_shortcode_speedbump\Form
 */
class GallerySettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ctd_gallery_admin_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'ctd_gallery.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('ctd_gallery.settings');

    $form['interstitial_ads_refresh'] = [
      '#type' => 'number',
      '#title' => $this->t('Slideshow interstitial ad refresh rate'),
      '#default_value' => $config->get('interstitial_ads_refresh')
    ];

    $form['slide_all_ads_refresh'] = [
      '#type' => 'number',
      '#title' => $this->t('Slides ad refresh rate. Does not include interstitial ad.'),
      '#default_value' => $config->get('slide_all_ads_refresh')
    ];

    $form['slide_url_alias'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Slide url alias'),
      '#default_value' => $config->get('slide_url_alias')
    ];

    $form['default_next_content'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Default Next Content Link'),
      '#default_value' => $config->get('default_next_content')
     ];

    $form['first_slide_path'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Path for first slide'),
      '#default_value' => $config->get('first_slide_path')
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Retrieve the configuration.
    $this->config('ctd_gallery.settings')
      ->set('interstitial_ads_refresh', $form_state->getValue('interstitial_ads_refresh'))
      ->set('slide_all_ads_refresh', $form_state->getValue('slide_all_ads_refresh'))
      ->set('slide_url_alias', $form_state->getValue('slide_url_alias'))
      ->set('default_next_content', $form_state->getValue('default_next_content'))
      ->set('first_slide_path', $form_state->getValue('first_slide_path'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}