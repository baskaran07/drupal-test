<?php

namespace Drupal\ctd_gallery\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Slide entities.
 *
 * @ingroup ctd_gallery
 */
class SlideEntityDeleteForm extends ContentEntityDeleteForm {


}
