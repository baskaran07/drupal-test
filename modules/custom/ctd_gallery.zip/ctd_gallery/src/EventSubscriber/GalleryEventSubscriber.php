<?php

namespace Drupal\ctd_gallery\EventSubscriber;

use Drupal\node\Entity\Node;
use Drupal\Core\Path\AliasManagerInterface;
use Drupal\Core\Url;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Event Subscriber for Gallery content type
 */
class GalleryEventSubscriber implements EventSubscriberInterface {


  /**
   * The path for the first slide
   *
   * @var String
   */
  protected $firstSlidePath;

  /**
   * The path alias manager.
   *
   * @var \Drupal\Core\Path\AliasManagerInterface
   */
  protected $aliasManager;

  /**
   * Constructs a new GalleryEventSubscriber.
   *
   * @param \Drupal\Core\Path\AliasManagerInterface $alias_manager
   *    The path alias manager.context
   * @param string $firstSlidePath
   *    The configured path that redirects to first slide of a gallery
   *
   */
  public function __construct(AliasManagerInterface $alias_manager) {
    $this->aliasManager = $alias_manager;
    $this->firstSlidePath = \Drupal::config('ctd_gallery.settings')->get('first_slide_path');
  }

  /**
   * Subscribe to KernelEvents::REQUEST events and redirect request for
   * first Gallery slide
   *
   * {@inheritdoc}
   */
  static function getSubscribedEvents() {
    $events[KernelEvents::REQUEST][] = ['checkForRedirection'];
    return $events;
  }

  /**
   * Check request for redirect to first slide of a gallery
   *
   * @param GetResponseEvent $event
   *
   */
  public function checkForRedirection(GetResponseEvent $event) {
    // Get the requested path minus the base path.
    $requestPath = $event->getRequest()->getPathInfo();

    // Check if path contains the first slide path.
    if (!$this->firstSlidePath || substr($requestPath, strlen($requestPath) - strlen($this->firstSlidePath)) !== $this->firstSlidePath) {
      return;
    }

    // Extract the node from path.
    if ($nodePath = $this->aliasManager->getPathByAlias(substr($requestPath, 0, -strlen($this->firstSlidePath)))) {
      if(preg_match('/node\/(\d+)/', $nodePath, $matches)) {
        $node = Node::load($matches[1]);
      }
    }

    // Check if the node is a gallery content type.
    if (!isset($node) || $node->bundle() !== 'gallery') {
      return;
    }

    // Redirect to the first slide of the gallery.
    if(!$node->get('field_slides')->isEmpty() && $firstSlideEntity = $node->get('field_slides')->referencedEntities()[0]) {
      $firstSlideUrl = Url::fromRoute('entity.slide.canonical', ['gallery' => $node->id(), 'slide'=> $firstSlideEntity->id()]);
      // Add query string to the redirect URL.
      if ($query_string =  $event->getRequest()->getQueryString()) {
        parse_str($query_string, $options);
        $firstSlideUrl->setOption('query', (array) $options);
      }
      $response = new RedirectResponse($firstSlideUrl->toString(), 302);
      return $response->send();
    }

  }
}