CTD_AMP Module
==============

## Summary
This module provides CTD-specific code for Google
Accelerated Mobile Pages (AMP).

## Installation
Add the following to the `repositories` in `composer.json`. Run `composer require cbstvd/ctd_amp`.
```
{
    "type": "git",
    "url": "ssh://git@owl.cbsi.com:7999/cbstvd/ctd_amp.git"
}
```

### Dependencies

Depends on [AMP](https://www.drupal.org/project/amp)

## AMP Ads

### Place an AMP ad
Use the `place_amp_ad` Twig function to place an `<amp-ad>` HTML tag
into the page. The function takes two arguments.

1. Type: This should be a lower-case string. Use the same value as the 'type'
parameter in the [example docs](https://github.com/ampproject/amphtml/tree/master/ads)
All possible AMP ad types are defined [here](https://www.ampproject.org/docs/reference/components/amp-ad#supported-ad-networks).

For example:

| Name           | Type        |
| -------------- | ----------- |
| Doubleclick    | doubleclick |
| Index Exchange | ix          |
| Revcontent     | revcontent  |
| GumGum         | gumgum      |

2. Attributes: An array of HTML attributes that go on the `<amp-ad>` tag.

#### Example place_amp_ad() function call
```
{{
  place_amp_ad(
    'doubleclick',
    {
      'width': '320',
      'height': '50',
      'class': 'leaderboard',
      'data-slot': '/7336/maw-insideedition/headlines/article_1',
      'data-multi-size': '300x250,320x50',
      'data-multi-size-validation': 'false',
      'json': {
        'targeting': {
          'pos': ['atf', 'a']
        }
      }
    }
  )
}}
```

#### HTML result
```
<amp-ad
    width="320"
    height="50"
    class="leaderboard"
    data-slot="/7336/maw-insideedition/headlines/article_1"
    data-multi-size="300x250,320x50"
    data-multi-size-validation="false"
    json="{"targeting":{"pos":["atf","a"]}}"
    type="doubleclick"
>
</amp-ad>
```

### Ad-type variables
Use the `ctd_amp_preprocess_amp_ad_slot` to obtain node-specific variables or
overarching ad type configuration from Drupal.

If you need to conduct preprocess operations for specific ad types, implement
the `hook_preprocess_HOOK` function in this manner. "AD_TYPE" is the same as
the "type" attribute in the `place_amp_ad` function.

```
ctd_amp_preprocess_amp_ad_slot__AD_TYPE
```

For example, `ctd_amp_preprocess_amp_ad_slot__doubleclick` can be used to set
and modify variables specific to DFP.

Place a `amp-ad-slot--doubleclick.html.twig` in your AMP theme folder to theme
a Doubleclick-specific `<amp-ad>` tag.

### Future Functionality
* Provide defaults for all ads
* Provide defaults for specific ad types

## Other Documentation

See [this Confluence document](https://owl.cbsi.com/confluence/display/CTDDM/ctd_amp)
