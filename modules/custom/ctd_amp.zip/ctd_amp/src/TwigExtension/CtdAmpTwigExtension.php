<?php

namespace Drupal\ctd_amp\TwigExtension;

/**
 * Class CtdAmpTwigExtension.
 *
 * Contains CTD AMP twig functions.
 *
 * @package Drupal\ie_amp_ad\TwigExtension
 */
class CtdAmpTwigExtension extends \Twig_Extension {

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [
      new \Twig_SimpleFunction('place_amp_ad', [$this, 'placeAmpAd']),
    ];
  }

  /**
   * Place the HTML representation of an ad.
   *
   * @param string $type
   *   The ad type.
   * @param array $attributes
   *   Contextual variables about the specific ad.
   *
   * @return array
   *   A render array containing the data needed to create
   *   a slot HTML tag.
   */
  public function placeAmpAd($type, array $attributes) {
    $attributes['type'] = $type;

    $element = [
      '#theme' => 'amp_ad_slot',
      '#attributes' => $attributes,
    ];

    return $element;
  }

}
